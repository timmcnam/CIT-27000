package Lab01;

public class Task01 {

	public static void main(String[] args) {
		String nameAndId = "Timothy McNamara | 2000580001";
		
		System.out.println(nameAndId);
		System.out.println("Welcome to Java I Course");

	}

}
